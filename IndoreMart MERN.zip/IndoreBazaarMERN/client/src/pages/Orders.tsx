import { useQuery } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, Calendar } from 'lucide-react';
import type { OrderWithItems } from '@shared/schema';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';

export default function Orders() {
  const [, setLocation] = useLocation();

  const { data: orders, isLoading } = useQuery<OrderWithItems[]>({
    queryKey: ['/api/orders'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-[1280px] mx-auto px-6 py-8">
          <Card className="h-96 animate-pulse bg-muted" />
        </div>
      </div>
    );
  }

  if (!orders || orders.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-12 text-center max-w-md">
          <div className="w-16 h-16 rounded-full bg-muted mx-auto flex items-center justify-center mb-4">
            <Package className="w-8 h-8 text-muted-foreground" />
          </div>
          <h2 className="font-heading font-semibold text-2xl text-foreground mb-2">
            No orders yet
          </h2>
          <p className="text-muted-foreground mb-6">
            Start shopping to place your first order
          </p>
          <Button onClick={() => setLocation('/')} data-testid="button-start-shopping">
            Start Shopping
          </Button>
        </Card>
      </div>
    );
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'delivered':
        return 'default';
      case 'confirmed':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[1280px] mx-auto px-6 py-8 space-y-6">
        <div>
          <h1 className="font-heading font-bold text-3xl text-foreground">My Orders</h1>
          <p className="text-muted-foreground mt-1">
            Track and manage your orders
          </p>
        </div>

        <div className="space-y-4">
          {orders.map((order) => (
            <Card key={order.id} className="p-6 space-y-4" data-testid={`card-order-${order.id}`}>
              <div className="flex items-start justify-between flex-wrap gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-heading font-semibold text-lg text-foreground">
                      Order #{order.id.substring(0, 8)}
                    </h3>
                    <Badge variant={getStatusBadgeVariant(order.status)} data-testid={`badge-order-status-${order.id}`}>
                      {order.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    <span>
                      {order.createdAt ? format(new Date(order.createdAt), 'PPP') : 'N/A'}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Total Amount</p>
                  <p className="text-2xl font-heading font-bold text-primary" data-testid={`text-order-total-${order.id}`}>
                    ₹{parseFloat(order.totalPrice).toFixed(2)}
                  </p>
                </div>
              </div>

              <div className="space-y-2 pt-4 border-t">
                <h4 className="font-medium text-foreground">Items ({order.items.length})</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {order.items.map((item) => (
                    <div
                      key={item.id}
                      className="flex gap-3 p-3 rounded-md bg-muted/50"
                      data-testid={`item-order-${item.id}`}
                    >
                      <div className="w-12 h-12 rounded overflow-hidden bg-background flex-shrink-0">
                        <img
                          src={item.product.imageUrl}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm text-foreground line-clamp-1">
                          {item.product.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Qty: {item.quantity} × ₹{parseFloat(item.price).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
