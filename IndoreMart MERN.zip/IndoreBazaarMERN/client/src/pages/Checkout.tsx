import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, Package } from 'lucide-react';
import type { CartItemWithProduct } from '@shared/schema';
import { useLocation } from 'wouter';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [orderPlaced, setOrderPlaced] = useState(false);

  const { data: cartItems, isLoading } = useQuery<CartItemWithProduct[]>({
    queryKey: ['/api/cart'],
  });

  const subtotal = cartItems?.reduce(
    (sum, item) => sum + parseFloat(item.product.price) * item.quantity,
    0
  ) || 0;

  const tax = subtotal * 0.18;
  const total = subtotal + tax;

  const placeOrderMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/orders', {
      totalPrice: total.toFixed(2),
      status: 'pending',
    }),
    onSuccess: () => {
      // queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      // queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
      setOrderPlaced(true);
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to place order. Please try again.',
        variant: 'destructive',
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-[800px] mx-auto px-6 py-8">
          <Card className="h-96 animate-pulse bg-muted" />
        </div>
      </div>
    );
  }

  if (!cartItems || cartItems.length === 0) {
    setLocation('/cart');
    return null;
  }

  if (orderPlaced) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-12 text-center max-w-md">
          <div className="w-16 h-16 rounded-full bg-primary/10 mx-auto flex items-center justify-center mb-4">
            <CheckCircle2 className="w-8 h-8 text-primary" />
          </div>
          <h2 className="font-heading font-bold text-2xl text-foreground mb-2">
            Order Placed Successfully!
          </h2>
          <p className="text-muted-foreground mb-6">
            Thank you for your order. You can track it in your orders page.
          </p>
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setLocation('/')}
              data-testid="button-continue-shopping"
            >
              Continue Shopping
            </Button>
            <Button
              onClick={() => setLocation('/orders')}
              data-testid="button-view-orders"
            >
              View Orders
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[800px] mx-auto px-6 py-8 space-y-6">
        <div>
          <h1 className="font-heading font-bold text-3xl text-foreground">Checkout</h1>
          <p className="text-muted-foreground mt-1">Review and place your order</p>
        </div>

        <div className="space-y-6">
          <Card className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-heading font-semibold text-xl text-foreground">
                Order Items
              </h2>
              <Badge>{cartItems.length} items</Badge>
            </div>

            <div className="space-y-3">
              {cartItems.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-4 pb-3 border-b last:border-0"
                  data-testid={`item-checkout-${item.id}`}
                >
                  <div className="w-16 h-16 rounded-md overflow-hidden bg-muted flex-shrink-0">
                    <img
                      src={item.product.imageUrl}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-foreground">{item.product.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      Quantity: {item.quantity}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-foreground">
                      ₹{(parseFloat(item.product.price) * item.quantity).toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6 space-y-4">
            <h2 className="font-heading font-semibold text-xl text-foreground">
              Order Summary
            </h2>

            <div className="space-y-2">
              <div className="flex justify-between text-foreground">
                <span>Subtotal</span>
                <span data-testid="text-checkout-subtotal">₹{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-foreground">
                <span>Tax (18% GST)</span>
                <span data-testid="text-checkout-tax">₹{tax.toFixed(2)}</span>
              </div>
              <div className="pt-2 border-t flex justify-between font-heading font-bold text-xl text-foreground">
                <span>Total</span>
                <span data-testid="text-checkout-total">₹{total.toFixed(2)}</span>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-primary/5 border-primary/20">
            <div className="flex gap-3">
              <Package className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-medium text-foreground">Local Delivery in Indore</p>
                <p className="text-sm text-muted-foreground">
                  Your order will be delivered by local vendors in your area
                </p>
              </div>
            </div>
          </Card>

          <Button
            size="lg"
            className="w-full"
            onClick={() => placeOrderMutation.mutate()}
            disabled={placeOrderMutation.isPending}
            data-testid="button-place-order"
          >
            {placeOrderMutation.isPending ? 'Placing Order...' : 'Place Order'}
          </Button>
        </div>
      </div>
    </div>
  );
}
