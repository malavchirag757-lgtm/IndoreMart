import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/ProductCard';
import { Badge } from '@/components/ui/badge';
import type { ProductWithVendor } from '@shared/schema';
import { Card } from '@/components/ui/card';

const categories = [
  'All',
  'Electronics',
  'Fashion',
  'Home & Kitchen',
  'Books',
  'Sports',
  'Beauty',
  'Food',
  'Groceries',
];

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const { data: products, isLoading } = useQuery<ProductWithVendor[]>({
    queryKey: ['/api/products'],
  });

  const filteredProducts = products?.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  }) || [];

  return (
    <div className="min-h-screen bg-background">
      <div 
        className="relative h-[600px] bg-gradient-to-br from-primary/20 via-background to-primary/10 flex items-center justify-center"
        style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1534452203293-494d7ddbf7e0?q=80&w=2072)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background"></div>
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center space-y-8">
          <h1 className="font-heading font-bold text-5xl sm:text-6xl text-foreground drop-shadow-lg">
            Indore's Local Marketplace
          </h1>
          <p className="text-xl sm:text-2xl text-foreground/90 font-medium">
            Support local vendors, shop local products
          </p>
          
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search for products..."
                className="pl-12 h-14 text-base bg-background/95 backdrop-blur-sm border-2"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                data-testid="input-search-products"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-2 justify-center">
            <Button 
              variant="default" 
              size="lg"
              className="gap-2 backdrop-blur-sm bg-primary/90 hover:bg-primary"
            >
              Browse Products
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-[1280px] mx-auto px-6 py-12 space-y-8">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h2 className="font-heading font-semibold text-3xl text-foreground">
              Featured Products
            </h2>
            <p className="text-muted-foreground mt-1">
              Discover quality products from local vendors in Indore
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Filter by:</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <Badge
              key={category}
              variant={selectedCategory === category ? 'default' : 'secondary'}
              className="cursor-pointer px-4 py-2 text-sm hover-elevate active-elevate-2"
              onClick={() => setSelectedCategory(category)}
              data-testid={`badge-category-${category.toLowerCase().replace(/\s+/g, '-')}`}
            >
              {category}
            </Badge>
          ))}
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="h-[400px] animate-pulse bg-muted" />
            ))}
          </div>
        ) : filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <div className="max-w-md mx-auto space-y-4">
              <div className="w-16 h-16 rounded-full bg-muted mx-auto flex items-center justify-center">
                <Search className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-heading font-semibold text-xl text-foreground">
                No products found
              </h3>
              <p className="text-muted-foreground">
                Try adjusting your search or filter to find what you're looking for
              </p>
            </div>
          </Card>
        )}
      </div>

      <div className="bg-card border-t py-16">
        <div className="max-w-[1280px] mx-auto px-6">
          <div className="text-center space-y-4 mb-12">
            <h2 className="font-heading font-semibold text-3xl text-card-foreground">
              How It Works
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Join our community of local vendors and customers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="p-8 space-y-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-2xl font-bold text-primary">1</span>
              </div>
              <h3 className="font-heading font-semibold text-xl text-foreground">For Vendors</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>• Register as a vendor with your shop details</li>
                <li>• Upload products with photos and descriptions</li>
                <li>• Manage your inventory and orders</li>
                <li>• Reach customers across Indore</li>
              </ul>
            </Card>

            <Card className="p-8 space-y-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-2xl font-bold text-primary">2</span>
              </div>
              <h3 className="font-heading font-semibold text-xl text-foreground">For Customers</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>• Browse products from local vendors</li>
                <li>• Add items to cart and checkout</li>
                <li>• Track your orders in real-time</li>
                <li>• Support your local community</li>
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
