import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { CartItemCard } from '@/components/CartItemCard';
import { ShoppingBag, ArrowRight } from 'lucide-react';
import type { CartItemWithProduct } from '@shared/schema';
import { useLocation } from 'wouter';

export default function Cart() {
  const [, setLocation] = useLocation();

  const { data: cartItems, isLoading } = useQuery<CartItemWithProduct[]>({
    queryKey: ['/api/cart'],
  });

  const subtotal = cartItems?.reduce(
    (sum, item) => sum + parseFloat(item.product.price) * item.quantity,
    0
  ) || 0;

  const tax = subtotal * 0.18; // 18% GST
  const total = subtotal + tax;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-[1280px] mx-auto px-6 py-8">
          <Card className="h-96 animate-pulse bg-muted" />
        </div>
      </div>
    );
  }

  if (!cartItems || cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-12 text-center max-w-md">
          <div className="w-16 h-16 rounded-full bg-muted mx-auto flex items-center justify-center mb-4">
            <ShoppingBag className="w-8 h-8 text-muted-foreground" />
          </div>
          <h2 className="font-heading font-semibold text-2xl text-foreground mb-2">
            Your cart is empty
          </h2>
          <p className="text-muted-foreground mb-6">
            Add some products to get started
          </p>
          <Button onClick={() => setLocation('/')} data-testid="button-continue-shopping">
            Start Shopping
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[1280px] mx-auto px-6 py-8 space-y-6">
        <div>
          <h1 className="font-heading font-bold text-3xl text-foreground">Shopping Cart</h1>
          <p className="text-muted-foreground mt-1">
            {cartItems.length} {cartItems.length === 1 ? 'item' : 'items'} in your cart
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map((item) => (
              <CartItemCard key={item.id} item={item} />
            ))}
          </div>

          <div className="lg:col-span-1">
            <Card className="p-6 space-y-4 lg:sticky lg:top-24">
              <h2 className="font-heading font-semibold text-xl text-foreground">
                Order Summary
              </h2>

              <div className="space-y-2 py-4 border-b">
                <div className="flex justify-between text-foreground">
                  <span>Subtotal</span>
                  <span data-testid="text-subtotal">₹{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-foreground">
                  <span>Tax (18% GST)</span>
                  <span data-testid="text-tax">₹{tax.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-between font-heading font-bold text-xl text-foreground">
                <span>Total</span>
                <span data-testid="text-total">₹{total.toFixed(2)}</span>
              </div>

              <Button
                size="lg"
                className="w-full gap-2"
                onClick={() => setLocation('/checkout')}
                data-testid="button-checkout"
              >
                Proceed to Checkout
                <ArrowRight className="w-4 h-4" />
              </Button>

              <Button
                variant="outline"
                size="lg"
                className="w-full"
                onClick={() => setLocation('/')}
                data-testid="button-continue-shopping"
              >
                Continue Shopping
              </Button>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
