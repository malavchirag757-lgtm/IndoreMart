import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertUserSchema, type InsertUser } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useAuth } from '@/contexts/AuthContext';
import { useLocation, Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { UserPlus, User, Store } from 'lucide-react';

export default function Signup() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [selectedRole, setSelectedRole] = useState<'customer' | 'vendor'>('customer');

  const form = useForm<InsertUser>({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      name: '',
      email: '',
      password: '',
      role: 'customer',
      shopName: '',
    },
  });

  const handleRoleChange = (role: 'customer' | 'vendor') => {
    setSelectedRole(role);
    form.setValue('role', role);
    if (role === 'customer') {
      form.setValue('shopName', '');
    }
  };

  const onSubmit = async (data: InsertUser) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Signup failed');
      }

      const result = await response.json();
      
      // Login and store user data
      login(result.user, result.token);
      
      // Show success message
      toast({
        title: 'Account created!',
        description: 'Welcome to IndoreBazaar',
      });

      // Redirect based on role immediately after login
      // Using setTimeout to ensure state updates are processed
      setTimeout(() => {
        if (result.user.role === 'vendor') {
          setLocation('/vendor/dashboard');
        } else {
          setLocation('/');
        }
      }, 100);
    } catch (error) {
      toast({
        title: 'Signup failed',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <Card className="w-full max-w-md p-8 space-y-6">
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-full bg-primary/10 mx-auto flex items-center justify-center">
            <UserPlus className="w-8 h-8 text-primary" />
          </div>
          <h1 className="font-heading font-bold text-3xl text-foreground">Create Account</h1>
          <p className="text-muted-foreground">Join IndoreBazaar today</p>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">I am a:</label>
          <div className="grid grid-cols-2 gap-3">
            <Badge
              variant={selectedRole === 'customer' ? 'default' : 'secondary'}
              className="cursor-pointer h-auto p-4 flex flex-col items-center gap-2 hover-elevate active-elevate-2"
              onClick={() => handleRoleChange('customer')}
              data-testid="badge-role-customer"
            >
              <User className="w-6 h-6" />
              <span className="font-medium">Customer</span>
            </Badge>
            <Badge
              variant={selectedRole === 'vendor' ? 'default' : 'secondary'}
              className="cursor-pointer h-auto p-4 flex flex-col items-center gap-2 hover-elevate active-elevate-2"
              onClick={() => handleRoleChange('vendor')}
              data-testid="badge-role-vendor"
            >
              <Store className="w-6 h-6" />
              <span className="font-medium">Vendor</span>
            </Badge>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="John Doe"
                      data-testid="input-name"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input
                      type="email"
                      placeholder="your@email.com"
                      data-testid="input-email"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {selectedRole === 'vendor' && (
              <FormField
                control={form.control}
                name="shopName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Shop Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="My Shop"
                        data-testid="input-shop-name"
                        {...field}
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input
                      type="password"
                      placeholder="••••••••"
                      data-testid="input-password"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full"
              size="lg"
              disabled={isLoading}
              data-testid="button-signup"
            >
              {isLoading ? 'Creating account...' : 'Create Account'}
            </Button>
          </form>
        </Form>

        <div className="text-center space-y-2">
          <p className="text-sm text-muted-foreground">
            Already have an account?{' '}
            <Link href="/login" data-testid="link-login">
              <span className="text-primary font-medium hover:underline cursor-pointer">
                Login
              </span>
            </Link>
          </p>
        </div>
      </Card>
    </div>
  );
}
