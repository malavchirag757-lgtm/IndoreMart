import { useQuery, useMutation } from '@tanstack/react-query';
import { useParams, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, MapPin, Store, ArrowLeft, Minus, Plus } from 'lucide-react';
import type { ProductWithVendor } from '@shared/schema';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';

export default function ProductDetails() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { isCustomer } = useAuth();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);

  const { data: product, isLoading } = useQuery<ProductWithVendor>({
    queryKey: ['/api/products', id],
  });

  const addToCartMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/cart', {
      productId: id,
      quantity,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: 'Added to cart',
        description: `${quantity} item(s) added to your cart`,
      });
      setQuantity(1);
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to add item to cart',
        variant: 'destructive',
      });
    },
  });

  const handleAddToCart = () => {
    if (isCustomer) {
      addToCartMutation.mutate();
    } else {
      setLocation('/login');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-[1280px] mx-auto px-6 py-8">
          <Card className="h-[600px] animate-pulse bg-muted" />
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-12 text-center max-w-md">
          <h2 className="font-heading font-semibold text-2xl text-foreground mb-2">
            Product not found
          </h2>
          <p className="text-muted-foreground mb-6">
            The product you're looking for doesn't exist
          </p>
          <Button onClick={() => setLocation('/')} data-testid="button-back-home">
            Back to Home
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[1280px] mx-auto px-6 py-8 space-y-6">
        <Button
          variant="ghost"
          onClick={() => setLocation('/')}
          className="gap-2"
          data-testid="button-back"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Products
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <Card className="overflow-hidden aspect-square">
              <img
                src={product.imageUrl}
                alt={product.name}
                className="w-full h-full object-cover"
                data-testid="img-product-detail"
              />
            </Card>
          </div>

          <div className="space-y-6">
            <div className="space-y-3">
              <Badge variant="secondary" data-testid="badge-category">
                {product.category}
              </Badge>
              <h1 className="font-heading font-bold text-4xl text-foreground" data-testid="text-product-name">
                {product.name}
              </h1>
              <p className="text-3xl font-heading font-bold text-primary" data-testid="text-product-price">
                ₹{parseFloat(product.price).toFixed(2)}
              </p>
            </div>

            <Card className="p-6 space-y-3">
              <div className="flex items-center gap-2">
                <Store className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-medium text-foreground">
                    {product.vendor?.shopName || product.vendor?.name || 'Unknown Vendor'}
                  </p>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <MapPin className="w-3 h-3" />
                    <span>{product.location}</span>
                  </div>
                </div>
              </div>
            </Card>

            <div className="space-y-3">
              <h2 className="font-heading font-semibold text-xl text-foreground">
                Product Description
              </h2>
              <p className="text-muted-foreground leading-relaxed" data-testid="text-product-description">
                {product.description}
              </p>
            </div>

            {isCustomer && (
              <Card className="p-6 space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Quantity</label>
                  <div className="flex items-center gap-3">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={quantity <= 1}
                      data-testid="button-decrease-quantity"
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="w-12 text-center font-medium text-lg" data-testid="text-quantity">
                      {quantity}
                    </span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(quantity + 1)}
                      data-testid="button-increase-quantity"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <Button
                  size="lg"
                  className="w-full gap-2"
                  onClick={handleAddToCart}
                  disabled={addToCartMutation.isPending}
                  data-testid="button-add-to-cart"
                >
                  <ShoppingCart className="w-5 h-5" />
                  {addToCartMutation.isPending ? 'Adding...' : 'Add to Cart'}
                </Button>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
