import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Minus, Plus, Trash2 } from 'lucide-react';
import type { CartItemWithProduct } from '@shared/schema';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface CartItemCardProps {
  item: CartItemWithProduct;
}

export function CartItemCard({ item }: CartItemCardProps) {
  const { toast } = useToast();

  const updateQuantityMutation = useMutation({
    mutationFn: (quantity: number) => 
      apiRequest('PATCH', `/api/cart/${item.id}`, { quantity }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to update quantity',
        variant: 'destructive',
      });
    },
  });

  const removeItemMutation = useMutation({
    mutationFn: () => apiRequest('DELETE', `/api/cart/${item.id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: 'Removed from cart',
        description: 'Item has been removed from your cart',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to remove item',
        variant: 'destructive',
      });
    },
  });

  const itemTotal = parseFloat(item.product.price) * item.quantity;

  return (
    <Card className="p-4" data-testid={`card-cart-item-${item.id}`}>
      <div className="flex gap-4">
        <div className="w-24 h-24 flex-shrink-0 rounded-md overflow-hidden bg-muted">
          <img
            src={item.product.imageUrl}
            alt={item.product.name}
            className="w-full h-full object-cover"
            data-testid={`img-cart-item-${item.id}`}
          />
        </div>

        <div className="flex-1 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="font-heading font-semibold text-foreground" data-testid={`text-cart-item-name-${item.id}`}>
                {item.product.name}
              </h3>
              <p className="text-sm text-muted-foreground">{item.product.category}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => removeItemMutation.mutate()}
              disabled={removeItemMutation.isPending}
              data-testid={`button-remove-cart-item-${item.id}`}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => updateQuantityMutation.mutate(item.quantity - 1)}
                disabled={item.quantity <= 1 || updateQuantityMutation.isPending}
                data-testid={`button-decrease-quantity-${item.id}`}
              >
                <Minus className="w-3 h-3" />
              </Button>
              <span className="w-8 text-center font-medium" data-testid={`text-quantity-${item.id}`}>
                {item.quantity}
              </span>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => updateQuantityMutation.mutate(item.quantity + 1)}
                disabled={updateQuantityMutation.isPending}
                data-testid={`button-increase-quantity-${item.id}`}
              >
                <Plus className="w-3 h-3" />
              </Button>
            </div>

            <p className="text-lg font-heading font-bold text-primary" data-testid={`text-cart-item-total-${item.id}`}>
              ₹{itemTotal.toFixed(2)}
            </p>
          </div>
        </div>
      </div>
    </Card>
  );
}
