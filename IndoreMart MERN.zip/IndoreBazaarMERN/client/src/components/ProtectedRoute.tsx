import { ReactNode } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Redirect } from 'wouter';

interface ProtectedRouteProps {
  children: ReactNode;
  requireVendor?: boolean;
  requireCustomer?: boolean;
}

export function ProtectedRoute({ children, requireVendor, requireCustomer }: ProtectedRouteProps) {
  const { user, isVendor, isCustomer } = useAuth();

  if (!user) {
    return <Redirect to="/login" />;
  }

  if (requireVendor && !isVendor) {
    return <Redirect to="/" />;
  }

  if (requireCustomer && !isCustomer) {
    return <Redirect to="/" />;
  }

  return <>{children}</>;
}
