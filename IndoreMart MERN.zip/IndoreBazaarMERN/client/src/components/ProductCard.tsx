import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, MapPin, Store } from 'lucide-react';
import type { ProductWithVendor } from '@shared/schema';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface ProductCardProps {
  product: ProductWithVendor;
}

export function ProductCard({ product }: ProductCardProps) {
  const [, setLocation] = useLocation();
  const { isCustomer } = useAuth();
  const { toast } = useToast();

  const addToCartMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/cart', {
      productId: product.id,
      quantity: 1,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: 'Added to cart',
        description: `${product.name} has been added to your cart`,
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to add item to cart',
        variant: 'destructive',
      });
    },
  });

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isCustomer) {
      addToCartMutation.mutate();
    } else {
      setLocation('/login');
    }
  };

  return (
    <Card
      className="group cursor-pointer overflow-hidden hover-elevate active-elevate-2 transition-all duration-200"
      onClick={() => setLocation(`/product/${product.id}`)}
      data-testid={`card-product-${product.id}`}
    >
      <div className="aspect-square overflow-hidden bg-muted">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          data-testid={`img-product-${product.id}`}
        />
      </div>
      <div className="p-4 space-y-3">
        <div className="space-y-1">
          <h3 className="font-heading font-semibold text-lg text-foreground line-clamp-2 leading-tight" data-testid={`text-product-name-${product.id}`}>
            {product.name}
          </h3>
          <Badge variant="secondary" className="text-xs">
            {product.category}
          </Badge>
        </div>

        <p className="text-2xl font-heading font-bold text-primary" data-testid={`text-product-price-${product.id}`}>
          ₹{parseFloat(product.price).toFixed(2)}
        </p>

        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Store className="w-3 h-3" />
          <span className="line-clamp-1">{product.vendor?.shopName || product.vendor?.name || 'Unknown Vendor'}</span>
        </div>

        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <MapPin className="w-3 h-3" />
          <span>{product.location}</span>
        </div>

        {isCustomer && (
          <Button
            variant="default"
            size="default"
            className="w-full gap-2"
            onClick={handleAddToCart}
            disabled={addToCartMutation.isPending}
            data-testid={`button-add-to-cart-${product.id}`}
          >
            <ShoppingCart className="w-4 h-4" />
            {addToCartMutation.isPending ? 'Adding...' : 'Add to Cart'}
          </Button>
        )}
      </div>
    </Card>
  );
}
