import { ShoppingCart, User, LogOut, Package, Store } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import type { CartItemWithProduct } from '@shared/schema';

export function Header() {
  const [location, setLocation] = useLocation();
  const { user, logout, isVendor, isCustomer } = useAuth();

  const { data: cartItems } = useQuery<CartItemWithProduct[]>({
    queryKey: ['/api/cart'],
    enabled: isCustomer,
  });

  const cartCount = cartItems?.reduce((sum, item) => sum + item.quantity, 0) || 0;

  const handleLogout = () => {
    logout();
    setLocation('/');
  };

  return (
    <header className="sticky top-0 z-50 bg-background border-b">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          <Link href="/" data-testid="link-home">
            <div className="flex items-center gap-2 cursor-pointer hover-elevate active-elevate-2 px-3 py-2 rounded-md -ml-3">
              <Store className="w-8 h-8 text-primary" />
              <div>
                <h1 className="font-heading font-bold text-2xl text-foreground">IndoreBazaar</h1>
                <p className="text-xs text-muted-foreground">Indore's Local Marketplace</p>
              </div>
            </div>
          </Link>

          <div className="flex items-center gap-2">
            {user ? (
              <>
                <div className="hidden sm:flex items-center gap-2 mr-2">
                  <div className="text-right">
                    <p className="text-sm font-medium text-foreground">{user.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {isVendor ? user.shopName || 'Vendor' : 'Customer'}
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="w-5 h-5 text-primary" />
                  </div>
                </div>

                {isVendor && (
                  <Link href="/vendor/dashboard" data-testid="link-vendor-dashboard">
                    <Button variant="ghost" size="default" className="gap-2">
                      <Package className="w-4 h-4" />
                      <span className="hidden sm:inline">Dashboard</span>
                    </Button>
                  </Link>
                )}

                {isCustomer && (
                  <>
                    <Link href="/cart" data-testid="link-cart">
                      <Button variant="ghost" size="icon" className="relative">
                        <ShoppingCart className="w-5 h-5" />
                        {cartCount > 0 && (
                          <Badge 
                            variant="destructive" 
                            className="absolute -top-1 -right-1 h-5 min-w-5 px-1 text-xs flex items-center justify-center"
                            data-testid="badge-cart-count"
                          >
                            {cartCount}
                          </Badge>
                        )}
                      </Button>
                    </Link>
                    <Link href="/orders" data-testid="link-orders">
                      <Button variant="ghost" size="default" className="gap-2">
                        <Package className="w-4 h-4" />
                        <span className="hidden sm:inline">Orders</span>
                      </Button>
                    </Link>
                  </>
                )}

                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={handleLogout}
                  data-testid="button-logout"
                >
                  <LogOut className="w-5 h-5" />
                </Button>
              </>
            ) : (
              <>
                <Link href="/login" data-testid="link-login">
                  <Button variant="ghost" size="default">Login</Button>
                </Link>
                <Link href="/signup" data-testid="link-signup">
                  <Button variant="default" size="default">Sign Up</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
