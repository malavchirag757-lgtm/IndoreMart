import { storage } from './storage';
import bcrypt from 'bcrypt';

export async function seedData() {
  console.log('🌱 Seeding database...');

  try {
    // Create vendor users
    const vendor1Password = await bcrypt.hash('vendor123', 10);
    const vendor1 = await storage.createUser({
      name: 'Rajesh Kumar',
      email: 'rajesh@indore.com',
      password: vendor1Password,
      role: 'vendor',
      shopName: 'Kumar Electronics',
    });

    const vendor2Password = await bcrypt.hash('vendor123', 10);
    const vendor2 = await storage.createUser({
      name: 'Priya Sharma',
      email: 'priya@indore.com',
      password: vendor2Password,
      role: 'vendor',
      shopName: 'Sharma Fashion House',
    });

    const vendor3Password = await bcrypt.hash('vendor123', 10);
    const vendor3 = await storage.createUser({
      name: 'Amit Patel',
      email: 'amit@indore.com',
      password: vendor3Password,
      role: 'vendor',
      shopName: 'Patel Home Décor',
    });

    // Create customer user
    const customerPassword = await bcrypt.hash('customer123', 10);
    const customer = await storage.createUser({
      name: 'Anita Verma',
      email: 'anita@customer.com',
      password: customerPassword,
      role: 'customer',
      shopName: null,
    });

    // Create products for vendor 1 (Electronics)
    await storage.createProduct({
      name: 'Wireless Bluetooth Headphones',
      price: '2499.00',
      description: 'Premium quality wireless headphones with noise cancellation and 30-hour battery life. Perfect for music lovers and professionals.',
      category: 'Electronics',
      imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&h=500&fit=crop',
      vendorId: vendor1.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Smart Watch Series 5',
      price: '8999.00',
      description: 'Advanced smartwatch with heart rate monitoring, GPS tracking, and water resistance. Stay connected on the go.',
      category: 'Electronics',
      imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&h=500&fit=crop',
      vendorId: vendor1.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Portable Power Bank 20000mAh',
      price: '1299.00',
      description: 'High-capacity power bank with dual USB ports and fast charging support. Never run out of battery again.',
      category: 'Electronics',
      imageUrl: 'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=500&h=500&fit=crop',
      vendorId: vendor1.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Wireless Mouse & Keyboard Combo',
      price: '1599.00',
      description: 'Ergonomic wireless keyboard and mouse set with silent keys and long battery life. Perfect for office work.',
      category: 'Electronics',
      imageUrl: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=500&h=500&fit=crop',
      vendorId: vendor1.id,
      location: 'Indore',
    });

    // Create products for vendor 2 (Fashion)
    await storage.createProduct({
      name: 'Designer Cotton Kurti',
      price: '799.00',
      description: 'Traditional handcrafted cotton kurti with beautiful embroidery. Perfect for casual and festive wear.',
      category: 'Fashion',
      imageUrl: 'https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=500&h=500&fit=crop',
      vendorId: vendor2.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Premium Silk Saree',
      price: '3499.00',
      description: 'Elegant pure silk saree with intricate border work. Make a statement at any occasion.',
      category: 'Fashion',
      imageUrl: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=500&h=500&fit=crop',
      vendorId: vendor2.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Leather Handbag',
      price: '1999.00',
      description: 'Genuine leather handbag with multiple compartments. Stylish and practical for everyday use.',
      category: 'Fashion',
      imageUrl: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=500&h=500&fit=crop',
      vendorId: vendor2.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Men\'s Formal Shoes',
      price: '2299.00',
      description: 'Classic formal shoes made from premium leather. Perfect for office and formal occasions.',
      category: 'Fashion',
      imageUrl: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=500&h=500&fit=crop',
      vendorId: vendor2.id,
      location: 'Indore',
    });

    // Create products for vendor 3 (Home & Kitchen)
    await storage.createProduct({
      name: 'Ceramic Dinner Set (24 Pieces)',
      price: '2999.00',
      description: 'Beautiful ceramic dinner set with elegant design. Includes plates, bowls, and serving dishes for 6 people.',
      category: 'Home & Kitchen',
      imageUrl: 'https://images.unsplash.com/photo-1584990347449-46f04f8551fc?w=500&h=500&fit=crop',
      vendorId: vendor3.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Decorative Wall Clock',
      price: '899.00',
      description: 'Modern decorative wall clock with silent movement. Adds elegance to any room.',
      category: 'Home & Kitchen',
      imageUrl: 'https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?w=500&h=500&fit=crop',
      vendorId: vendor3.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Premium Cotton Bedsheet Set',
      price: '1499.00',
      description: 'Soft and comfortable cotton bedsheet set with 2 pillow covers. Available in multiple colors.',
      category: 'Home & Kitchen',
      imageUrl: 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=500&h=500&fit=crop',
      vendorId: vendor3.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Non-Stick Cookware Set',
      price: '3499.00',
      description: '5-piece non-stick cookware set including frying pans and saucepans. Dishwasher safe and durable.',
      category: 'Home & Kitchen',
      imageUrl: 'https://images.unsplash.com/photo-1556911220-bff31c812dba?w=500&h=500&fit=crop',
      vendorId: vendor3.id,
      location: 'Indore',
    });

    // More diverse products
    await storage.createProduct({
      name: 'The Complete Works of Shakespeare',
      price: '599.00',
      description: 'Hardcover edition containing all of Shakespeare\'s plays and sonnets. A must-have for literature lovers.',
      category: 'Books',
      imageUrl: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=500&h=500&fit=crop',
      vendorId: vendor3.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Yoga Mat with Carry Bag',
      price: '799.00',
      description: 'Premium quality yoga mat with excellent grip and cushioning. Includes free carry bag.',
      category: 'Sports',
      imageUrl: 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=500&h=500&fit=crop',
      vendorId: vendor1.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Organic Face Cream',
      price: '499.00',
      description: 'Natural organic face cream with aloe vera and vitamin E. Suitable for all skin types.',
      category: 'Beauty',
      imageUrl: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=500&h=500&fit=crop',
      vendorId: vendor2.id,
      location: 'Indore',
    });

    await storage.createProduct({
      name: 'Organic Honey (500g)',
      price: '349.00',
      description: 'Pure and natural organic honey sourced from local farms. Rich in nutrients and antioxidants.',
      category: 'Food',
      imageUrl: 'https://images.unsplash.com/photo-1587049352846-4a222e784354?w=500&h=500&fit=crop',
      vendorId: vendor3.id,
      location: 'Indore',
    });

    console.log('✅ Database seeded successfully!');
    console.log('\n📝 Test accounts created:');
    console.log('\nVendor Accounts:');
    console.log('  Email: rajesh@indore.com | Password: vendor123');
    console.log('  Email: priya@indore.com | Password: vendor123');
    console.log('  Email: amit@indore.com | Password: vendor123');
    console.log('\nCustomer Account:');
    console.log('  Email: anita@customer.com | Password: customer123');
    console.log('\n🛍️  Created 16 sample products across all categories\n');

  } catch (error) {
    console.error('❌ Error seeding database:', error);
    throw error;
  }
}
