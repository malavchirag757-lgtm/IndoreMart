import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import { body, validationResult } from "express-validator";
import {
  insertUserSchema,
  loginSchema,
  insertProductSchema,
  insertCartItemSchema,
  addToCartSchema,
  insertOrderSchema,
} from "@shared/schema";
import {
  authenticateToken,
  requireVendor,
  requireCustomer,
  generateToken,
  type AuthRequest,
} from "./middleware/auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 10);

      // Create user
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
      });

      // Generate token
      const token = generateToken(user);

      // Return user without password
      const { password, ...userWithoutPassword } = user;

      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      console.error("Signup error:", error);
      res.status(400).json({ message: "Invalid signup data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);

      // Find user
      const user = await storage.getUserByEmail(validatedData.email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Verify password
      const validPassword = await bcrypt.compare(
        validatedData.password,
        user.password
      );
      if (!validPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Generate token
      const token = generateToken(user);

      // Return user without password
      const { password, ...userWithoutPassword } = user;

      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      console.error("Login error:", error);
      res.status(400).json({ message: "Invalid login data" });
    }
  });

  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProductWithVendor(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  app.get(
    "/api/vendor/products",
    authenticateToken,
    requireVendor,
    async (req: AuthRequest, res) => {
      try {
        const products = await storage.getVendorProducts(req.user!.id);
        res.json(products);
      } catch (error) {
        console.error("Error fetching vendor products:", error);
        res.status(500).json({ message: "Failed to fetch products" });
      }
    }
  );

  app.post(
    "/api/products",
    authenticateToken,
    requireVendor,
    async (req: AuthRequest, res) => {
      try {
        const validatedData = insertProductSchema.parse(req.body);

        const product = await storage.createProduct({
          ...validatedData,
          vendorId: req.user!.id,
        });

        res.json(product);
      } catch (error) {
        console.error("Error creating product:", error);
        res.status(400).json({ message: "Invalid product data" });
      }
    }
  );

  app.patch(
    "/api/products/:id",
    authenticateToken,
    requireVendor,
    async (req: AuthRequest, res) => {
      try {
        const product = await storage.getProduct(req.params.id);
        if (!product) {
          return res.status(404).json({ message: "Product not found" });
        }

        // Verify ownership
        if (product.vendorId !== req.user!.id) {
          return res.status(403).json({ message: "Not authorized" });
        }

        const validatedData = insertProductSchema.partial().parse(req.body);

        const updatedProduct = await storage.updateProduct(
          req.params.id,
          validatedData
        );

        res.json(updatedProduct);
      } catch (error) {
        console.error("Error updating product:", error);
        res.status(400).json({ message: "Invalid product data" });
      }
    }
  );

  app.delete(
    "/api/products/:id",
    authenticateToken,
    requireVendor,
    async (req: AuthRequest, res) => {
      try {
        const product = await storage.getProduct(req.params.id);
        if (!product) {
          return res.status(404).json({ message: "Product not found" });
        }

        // Verify ownership
        if (product.vendorId !== req.user!.id) {
          return res.status(403).json({ message: "Not authorized" });
        }

        await storage.deleteProduct(req.params.id);
        res.json({ message: "Product deleted" });
      } catch (error) {
        console.error("Error deleting product:", error);
        res.status(500).json({ message: "Failed to delete product" });
      }
    }
  );

  // Cart routes
  app.get(
    "/api/cart",
    authenticateToken,
    requireCustomer,
    async (req: AuthRequest, res) => {
      try {
        const cartItems = await storage.getCartItems(req.user!.id);
        res.json(cartItems);
      } catch (error) {
        console.error("Error fetching cart:", error);
        res.status(500).json({ message: "Failed to fetch cart" });
      }
    }
  );

  app.post(
    "/api/cart",
    authenticateToken,
    requireCustomer,
    async (req: AuthRequest, res) => {
      try {
        const validatedData = addToCartSchema.parse(req.body);

        const cartItem = await storage.addCartItem({
          ...validatedData,
          userId: req.user!.id,
        });

        res.json(cartItem);
      } catch (error) {
        console.error("Error adding to cart:", error);
        res.status(400).json({ message: "Invalid cart data" });
      }
    }
  );

  app.patch(
    "/api/cart/:id",
    authenticateToken,
    requireCustomer,
    async (req: AuthRequest, res) => {
      try {
        const { quantity } = req.body;

        if (typeof quantity !== "number" || quantity < 1) {
          return res.status(400).json({ message: "Invalid quantity" });
        }

        const updatedItem = await storage.updateCartItem(
          req.params.id,
          quantity
        );

        if (!updatedItem) {
          return res.status(404).json({ message: "Cart item not found" });
        }

        res.json(updatedItem);
      } catch (error) {
        console.error("Error updating cart item:", error);
        res.status(500).json({ message: "Failed to update cart item" });
      }
    }
  );

  app.delete(
    "/api/cart/:id",
    authenticateToken,
    requireCustomer,
    async (req: AuthRequest, res) => {
      try {
        const deleted = await storage.deleteCartItem(req.params.id);
        if (!deleted) {
          return res.status(404).json({ message: "Cart item not found" });
        }
        res.json({ message: "Item removed from cart" });
      } catch (error) {
        console.error("Error removing cart item:", error);
        res.status(500).json({ message: "Failed to remove cart item" });
      }
    }
  );

  // Order routes
  app.get(
    "/api/orders",
    authenticateToken,
    requireCustomer,
    async (req: AuthRequest, res) => {
      try {
        const orders = await storage.getUserOrders(req.user!.id);
        res.json(orders);
      } catch (error) {
        console.error("Error fetching orders:", error);
        res.status(500).json({ message: "Failed to fetch orders" });
      }
    }
  );

  app.post(
    "/api/orders",
    authenticateToken,
    requireCustomer,
    async (req: AuthRequest, res) => {
      try {
        const validatedData = insertOrderSchema.parse(req.body);

        // Get cart items
        const cartItems = await storage.getCartItems(req.user!.id);
        if (cartItems.length === 0) {
          return res.status(400).json({ message: "Cart is empty" });
        }

        // Create order items from cart
        const orderItems = cartItems.map((item) => ({
          productId: item.productId,
          quantity: item.quantity,
          price: item.product.price,
        }));

        // Create order
        const order = await storage.createOrder(
          {
            ...validatedData,
            userId: req.user!.id,
          },
          orderItems
        );

        // Clear cart
        await storage.clearCart(req.user!.id);

        res.json(order);
      } catch (error) {
        console.error("Error creating order:", error);
        res.status(400).json({ message: "Invalid order data" });
      }
    }
  );

  const httpServer = createServer(app);

  return httpServer;
}
