import {
  type User,
  type InsertUser,
  type Product,
  type InsertProduct,
  type CartItem,
  type InsertCartItem,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type ProductWithVendor,
  type CartItemWithProduct,
  type OrderWithItems,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Product operations
  getAllProducts(): Promise<ProductWithVendor[]>;
  getProduct(id: string): Promise<Product | undefined>;
  getProductWithVendor(id: string): Promise<ProductWithVendor | undefined>;
  getVendorProducts(vendorId: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;

  // Cart operations
  getCartItems(userId: string): Promise<CartItemWithProduct[]>;
  addCartItem(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: string, quantity: number): Promise<CartItem | undefined>;
  deleteCartItem(id: string): Promise<boolean>;
  clearCart(userId: string): Promise<void>;

  // Order operations
  getUserOrders(userId: string): Promise<OrderWithItems[]>;
  createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;
  private cartItems: Map<string, CartItem>;
  private orders: Map<string, Order>;
  private orderItems: Map<string, OrderItem>;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Product operations
  async getAllProducts(): Promise<ProductWithVendor[]> {
    const productsArray = Array.from(this.products.values());
    return Promise.all(
      productsArray.map(async (product) => {
        const vendor = await this.getUser(product.vendorId);
        return {
          ...product,
          vendor: vendor ? {
            name: vendor.name,
            shopName: vendor.shopName,
          } : undefined,
        };
      })
    );
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductWithVendor(id: string): Promise<ProductWithVendor | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;

    const vendor = await this.getUser(product.vendorId);
    return {
      ...product,
      vendor: vendor ? {
        name: vendor.name,
        shopName: vendor.shopName,
      } : undefined,
    };
  }

  async getVendorProducts(vendorId: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.vendorId === vendorId
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = {
      ...insertProduct,
      id,
      createdAt: new Date(),
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(
    id: string,
    updates: Partial<InsertProduct>
  ): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;

    const updatedProduct = { ...product, ...updates };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id);
  }

  // Cart operations
  async getCartItems(userId: string): Promise<CartItemWithProduct[]> {
    const userCartItems = Array.from(this.cartItems.values()).filter(
      (item) => item.userId === userId
    );

    return Promise.all(
      userCartItems.map(async (item) => {
        const product = await this.getProduct(item.productId);
        if (!product) throw new Error("Product not found");
        return { ...item, product };
      })
    );
  }

  async addCartItem(insertItem: InsertCartItem): Promise<CartItem> {
    // Check if item already exists in cart
    const existingItem = Array.from(this.cartItems.values()).find(
      (item) =>
        item.userId === insertItem.userId &&
        item.productId === insertItem.productId
    );

    if (existingItem) {
      // Update quantity
      existingItem.quantity += insertItem.quantity;
      this.cartItems.set(existingItem.id, existingItem);
      return existingItem;
    }

    const id = randomUUID();
    const cartItem: CartItem = { ...insertItem, id };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async updateCartItem(
    id: string,
    quantity: number
  ): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (!item) return undefined;

    item.quantity = quantity;
    this.cartItems.set(id, item);
    return item;
  }

  async deleteCartItem(id: string): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(userId: string): Promise<void> {
    const userCartItems = Array.from(this.cartItems.entries()).filter(
      ([_, item]) => item.userId === userId
    );
    userCartItems.forEach(([id]) => this.cartItems.delete(id));
  }

  // Order operations
  async getUserOrders(userId: string): Promise<OrderWithItems[]> {
    const userOrders = Array.from(this.orders.values())
      .filter((order) => order.userId === userId)
      .sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      });

    return Promise.all(
      userOrders.map(async (order) => {
        const items = Array.from(this.orderItems.values())
          .filter((item) => item.orderId === order.id);

        const itemsWithProducts = await Promise.all(
          items.map(async (item) => {
            const product = await this.getProduct(item.productId);
            if (!product) throw new Error("Product not found");
            return { ...item, product };
          })
        );

        return { ...order, items: itemsWithProducts };
      })
    );
  }

  async createOrder(
    insertOrder: InsertOrder,
    items: InsertOrderItem[]
  ): Promise<Order> {
    const orderId = randomUUID();
    const order: Order = {
      ...insertOrder,
      id: orderId,
      createdAt: new Date(),
    };
    this.orders.set(orderId, order);

    // Create order items
    for (const item of items) {
      const orderItemId = randomUUID();
      const orderItem: OrderItem = {
        ...item,
        id: orderItemId,
        orderId,
      };
      this.orderItems.set(orderItemId, orderItem);
    }

    return order;
  }
}

export const storage = new MemStorage();
